"""High-level application harness for running MCP servers."""

from __future__ import annotations

import asyncio
from typing import Iterable, Optional

from .server_base import BaseMCPServer
from .tool_base import BaseTool


class MCPApplication:
    """Coordinates tool registration and server lifecycle for MCP deployments."""

    def __init__(self, server: BaseMCPServer, *, tools: Optional[Iterable[BaseTool]] = None) -> None:
        self.server = server

        if tools:
            for tool in tools:
                self.register_tool(tool)

    def register_tool(self, tool: BaseTool, *, aliases: Optional[Iterable[str]] = None) -> None:
        """Register a tool with the underlying server router."""
        self.server.register_tool(tool, aliases=aliases)

    def run(self) -> None:
        """Start the server, handling synchronous and asynchronous transports."""
        maybe_coroutine = self.server.serve()

        if asyncio.iscoroutine(maybe_coroutine):
            asyncio.run(maybe_coroutine)

