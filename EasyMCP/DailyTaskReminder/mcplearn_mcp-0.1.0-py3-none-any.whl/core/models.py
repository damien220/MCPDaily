"""Data models for MCP requests and responses."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass(slots=True)
class MCPRequest:
    """Represents a tool invocation request."""

    id: str
    tool: str
    payload: Dict[str, Any] = field(default_factory=dict)
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON-serialisable representation."""
        return {
            "id": self.id,
            "tool": self.tool,
            "payload": self.payload,
            "metadata": self.metadata,
        }


@dataclass(slots=True)
class MCPResponse:
    """Represents the outcome of a tool execution."""

    id: str
    status: str
    result: Any = None
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

    def is_success(self) -> bool:
        """Return True when the tool succeeded."""
        return self.status.lower() == "success"

    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON-serialisable representation."""
        return {
            "id": self.id,
            "status": self.status,
            "result": self.result,
            "error": self.error,
            "metadata": self.metadata,
        }

    @classmethod
    def success(cls, request: MCPRequest, result: Any, metadata: Optional[Dict[str, Any]] = None) -> "MCPResponse":
        """Convenience constructor for successful executions."""
        return cls(id=request.id, status="success", result=result, metadata=metadata)

    @classmethod
    def failure(cls, request: MCPRequest, error: str, metadata: Optional[Dict[str, Any]] = None) -> "MCPResponse":
        """Convenience constructor for failed executions."""
        return cls(id=request.id, status="error", error=error, metadata=metadata)
