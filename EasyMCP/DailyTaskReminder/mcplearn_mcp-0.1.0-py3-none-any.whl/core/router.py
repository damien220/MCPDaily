"""Routing utilities for dispatching MCP requests to tools."""

from __future__ import annotations

from typing import Dict, Iterable, Optional

from .models import MCPRequest, MCPResponse
from .tool_base import BaseTool


class ToolNotRegisteredError(KeyError):
    """Raised when attempting to access an unknown tool."""


class ToolRouter:
    """Simple name-based router for MCP tools."""

    def __init__(self) -> None:
        self._tools: Dict[str, BaseTool] = {}

    def register(self, tool: BaseTool, *, aliases: Optional[Iterable[str]] = None) -> None:
        """Register a tool under its primary name and optional aliases."""
        names = {tool.name.lower()}
        if aliases:
            names.update(alias.lower() for alias in aliases)

        for name in names:
            self._tools[name] = tool

    def unregister(self, name: str) -> None:
        """Remove a previously registered tool."""
        try:
            del self._tools[name.lower()]
        except KeyError as exc:
            raise ToolNotRegisteredError(name) from exc

    def resolve(self, name: str) -> BaseTool:
        """Return the tool associated with the given name."""
        try:
            return self._tools[name.lower()]
        except KeyError as exc:
            raise ToolNotRegisteredError(name) from exc

    def route(self, request: MCPRequest) -> MCPResponse:
        """Dispatch a request to the appropriate tool."""
        tool = self.resolve(request.tool)
        return tool(request)

