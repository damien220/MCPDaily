"""Abstract base server for MCP implementations."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Iterable, Optional

from .models import MCPRequest, MCPResponse
from .router import ToolRouter
from .tool_base import BaseTool


class BaseMCPServer(ABC):
    """Provides common functionality for concrete MCP servers."""

    def __init__(self, router: Optional[ToolRouter] = None) -> None:
        self.router = router or ToolRouter()

    def register_tool(self, tool: BaseTool, *, aliases: Optional[Iterable[str]] = None) -> None:
        """Register a tool with the server."""
        self.router.register(tool, aliases=aliases)

    def handle_request(self, request: MCPRequest) -> MCPResponse:
        """Resolve and execute the tool for the request."""
        return self.router.route(request)

    @abstractmethod
    def serve(self) -> None:
        """Begin serving requests for the concrete transport."""

