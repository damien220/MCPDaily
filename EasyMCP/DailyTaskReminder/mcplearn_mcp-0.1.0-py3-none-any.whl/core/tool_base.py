"""Base classes for defining MCP tools."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

from .models import MCPRequest, MCPResponse


class BaseTool(ABC):
    """Base class for all tools handled by the MCP server."""

    def __init__(self, name: Optional[str] = None, description: Optional[str] = None) -> None:
        self.name = name or self.default_name()
        self.description = (description or self.__doc__ or "").strip()

    def default_name(self) -> str:
        """Return a default tool name."""
        return self.__class__.__name__.lower()

    def validate(self, request: MCPRequest) -> None:
        """Hook for subclasses to validate incoming requests."""
        return None

    def __call__(self, request: MCPRequest) -> MCPResponse:
        """Execute the tool for the provided request."""
        self.validate(request)
        return self.handle(request)

    @abstractmethod
    def handle(self, request: MCPRequest) -> MCPResponse:
        """Execute the tool logic."""


class BaseLLMTool(BaseTool):
    """Base class for tools backed by a language model."""

    def __init__(self, model_name: str, max_tokens: int = 512, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.model_name = model_name
        self.max_tokens = max_tokens

    @abstractmethod
    def generate(self, prompt: str, **kwargs: Any) -> str:
        """Generate text from the underlying language model."""

    def handle(self, request: MCPRequest) -> MCPResponse:
        """Invoke the language model using the request payload."""
        prompt = request.payload.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            return MCPResponse.failure(request, "Missing 'prompt' in payload.")

        generation_args: Dict[str, Any] = {k: v for k, v in request.payload.items() if k != "prompt"}
        text = self.generate(prompt, **generation_args)
        return MCPResponse.success(request, {"text": text, "model": self.model_name})

