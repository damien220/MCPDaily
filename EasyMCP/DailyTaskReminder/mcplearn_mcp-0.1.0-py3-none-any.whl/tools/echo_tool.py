"""Example tool that echoes input back to the caller."""

from __future__ import annotations

from core.models import MCPRequest, MCPResponse
from core.tool_base import BaseTool


class EchoTool(BaseTool):
    """A minimal tool that returns the provided message."""

    def handle(self, request: MCPRequest) -> MCPResponse:
        message = request.payload.get("message")
        if message is None:
            return MCPResponse.failure(request, "Payload must include a 'message' field.")

        return MCPResponse.success(request, {"echo": message})

