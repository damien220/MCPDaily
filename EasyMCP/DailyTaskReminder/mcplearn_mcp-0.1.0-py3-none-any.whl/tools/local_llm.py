"""Dummy local LLM-backed tool for demonstration."""

from __future__ import annotations

from typing import Any

from core.tool_base import BaseLLMTool


class LocalLLMTool(BaseLLMTool):
    """A toy LLM implementation that fakes text generation."""

    def __init__(self, model_name: str = "local-dummy-001", **kwargs: Any) -> None:
        super().__init__(model_name=model_name, **kwargs)

    def generate(self, prompt: str, **kwargs: Any) -> str:
        """Return a deterministic pseudo-generation for quick testing."""
        temperature = kwargs.get("temperature", 0.0)
        suffix = f" [temp={temperature}]" if temperature else ""
        return f"{prompt.strip()} :: response from {self.model_name}{suffix}"

