"""Simple CLI transport for experimenting with the MCP server."""

from __future__ import annotations

import json
import sys
from typing import IO, Optional

from core.models import MCPRequest
from core.server_base import BaseMCPServer


class CLIServer(BaseMCPServer):
    """Reads JSON requests from stdin and writes responses to stdout."""

    def __init__(self, *, input_stream: Optional[IO[str]] = None, output_stream: Optional[IO[str]] = None):
        super().__init__()
        self._input = input_stream or sys.stdin
        self._output = output_stream or sys.stdout

    def serve(self) -> None:
        """Process requests until EOF."""
        self._output.write("MCP CLI server ready. Provide JSON per line.\n")
        self._output.flush()

        for line in self._input:
            stripped = line.strip()
            if not stripped:
                continue

            try:
                data = json.loads(stripped)
                request = MCPRequest(**data)
            except Exception as exc:  # broad fallback for quick prototyping
                self._output.write(json.dumps({"error": str(exc)}) + "\n")
                self._output.flush()
                continue

            response = self.handle_request(request)
            self._output.write(json.dumps(response.to_dict()) + "\n")
            self._output.flush()
