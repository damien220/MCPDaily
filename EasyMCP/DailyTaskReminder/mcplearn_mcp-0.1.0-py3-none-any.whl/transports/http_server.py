"""HTTP transport built with FastAPI."""

from __future__ import annotations

from typing import Any, Dict, Optional

from core.models import MCPRequest
from core.server_base import BaseMCPServer

try:  # FastAPI is optional at runtime
    from fastapi import FastAPI
    from pydantic import BaseModel, Field
except ImportError as exc:  # pragma: no cover - module guarded
    FastAPI = None  # type: ignore
    BaseModel = object  # type: ignore
    Field = None  # type: ignore
    _IMPORT_ERROR = exc
else:
    _IMPORT_ERROR = None


if FastAPI:

    class _InvokePayload(BaseModel):
        id: str
        tool: str
        payload: Dict[str, Any] = Field(default_factory=dict)
        metadata: Optional[Dict[str, Any]] = None


class HTTPServer(BaseMCPServer):
    """Expose MCP tools over HTTP."""

    def __init__(self, host: str = "127.0.0.1", port: int = 8000) -> None:
        super().__init__()
        if not FastAPI:
            raise RuntimeError("FastAPI is not installed") from _IMPORT_ERROR

        self.host = host
        self.port = port
        self.app = FastAPI(title="MCPLearn MCP Server")

        @self.app.post("/invoke")  # type: ignore[misc]
        async def invoke(payload: _InvokePayload) -> Dict[str, Any]:
            request = MCPRequest(
                id=payload.id,
                tool=payload.tool,
                payload=payload.payload,
                metadata=payload.metadata,
            )
            response = self.handle_request(request)
            return response.to_dict()

    def serve(self) -> None:
        """Launch a uvicorn server for local development."""
        if not FastAPI:
            raise RuntimeError("FastAPI is not installed") from _IMPORT_ERROR

        try:
            import uvicorn
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RuntimeError("uvicorn is required to serve HTTPServer directly.") from exc

        uvicorn.run(self.app, host=self.host, port=self.port, log_level="info")
