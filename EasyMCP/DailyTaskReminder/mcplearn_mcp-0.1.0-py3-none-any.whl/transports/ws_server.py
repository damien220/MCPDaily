"""WebSocket transport for the MCP server."""

from __future__ import annotations

import asyncio
import json
from typing import Any, Dict

from core.models import MCPRequest
from core.server_base import BaseMCPServer

try:
    import websockets
except ImportError as exc:  # pragma: no cover - optional dependency
    websockets = None  # type: ignore
    _IMPORT_ERROR = exc
else:
    _IMPORT_ERROR = None


class WebSocketServer(BaseMCPServer):
    """Serve MCP tools over WebSocket connections."""

    def __init__(self, host: str = "127.0.0.1", port: int = 8765) -> None:
        super().__init__()
        self.host = host
        self.port = port

    async def serve(self) -> None:
        """Start the WebSocket server."""
        if not websockets:
            raise RuntimeError("websockets package is required for WebSocketServer.") from _IMPORT_ERROR

        async def handler(socket: websockets.WebSocketServerProtocol) -> None:
            async for message in socket:
                try:
                    data: Dict[str, Any] = json.loads(message)
                    request = MCPRequest(**data)
                    response = self.handle_request(request)
                    await socket.send(json.dumps(response.to_dict()))
                except Exception as exc:  # quick feedback for invalid payloads
                    await socket.send(json.dumps({"error": str(exc)}))

        async with websockets.serve(handler, self.host, self.port):
            await asyncio.Future()  # run until cancelled

